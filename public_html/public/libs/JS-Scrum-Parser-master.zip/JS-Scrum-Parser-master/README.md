# JS Scrum Parser
Scrum parser made during my co-op at the Co-operators

# Description
A small JS web app that parses text from two different excel files (copy all and paste) and outputs a combined and organized version that can be copied into a new Excel file to create a chart displaying the effectiveness of defect resolution.

# How to Try Out
Download the source and open "index.html". From there you paste each Excel file to their labeled areas then click "Submit". There you the program will out a bunch of text that looks like an unfinished table. Simply copy the whole thing and paste into a blank Excel file, and viola! A nice summary of the two scrum reports.

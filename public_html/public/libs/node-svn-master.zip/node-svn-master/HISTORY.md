0.3.0
===
* Added paths to log
* log now uses spawn


0.2.0
===
* Added externals and info commands
